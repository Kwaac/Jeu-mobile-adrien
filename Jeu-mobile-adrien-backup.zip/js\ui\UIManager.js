export default class UIManager {
    constructor(game) {
        this.game = game;
        this.uiLayer = document.getElementById('ui-layer');
        this.currentScreen = null;

        this.screens = {
            MAIN_MENU: 'main-menu',
            BATTLE_HUD: 'battle-hud',
            EQUIPMENT: 'equipment-screen',
            SHOP: 'shop-screen',
            INVENTORY: 'inventory-screen',
            QUEST_SELECT: 'quest-screen',
            EVOLUTION: 'evolution-screen'
        };

        this.initScreens();
        this.showScreen(this.screens.MAIN_MENU);

        // Hide debug overlay after initialization
        const debugOverlay = document.getElementById('debug-overlay');
        if (debugOverlay) {
            debugOverlay.style.display = 'none';
        }
    }

    initScreens() {
        // Clear existing content (except debug overlay)
        const debug = document.getElementById('debug-overlay');
        this.uiLayer.innerHTML = '';
        if (debug) this.uiLayer.appendChild(debug);

        // Create Main Menu
        const mainMenu = document.createElement('div');
        mainMenu.id = this.screens.MAIN_MENU;
        mainMenu.className = 'screen';
        mainMenu.innerHTML = `
            <div class="menu-header">
                <h2 style="font-family: 'Poppins', sans-serif; font-size: 24px; margin: 0;">⚔️ Brave RPG</h2>
                <div class="resources-display">
                    <div class="resource-item">
                        <span class="resource-icon">💎</span>
                        <span id="gems-count">0</span>
                    </div>
                    <div class="resource-item">
                        <span class="resource-icon">🪙</span>
                        <span id="gold-count">0</span>
                    </div>
                    <div class="resource-item">
                        <span class="resource-icon">⚡</span>
                        <span id="energy-count">100</span>
                    </div>
                </div>
            </div>
            <h1>Brave RPG</h1>
            <div class="menu-cards">
                <div class="menu-card" id="card-battle">
                    <div class="menu-card-content">
                        <div class="menu-card-icon">⚔️</div>
                        <h3>Combat</h3>
                        <p>Partez en quête et affrontez vos ennemis</p>
                    </div>
                </div>
                <div class="menu-card" id="card-equip">
                    <div class="menu-card-content">
                        <div class="menu-card-icon">👥</div>
                        <h3>Équipe</h3>
                        <p>Gérez votre équipe et votre équipement</p>
                    </div>
                </div>
                <div class="menu-card" id="card-inventory">
                    <div class="menu-card-content">
                        <div class="menu-card-icon">🎒</div>
                        <h3>Inventaire</h3>
                        <p>Gérez vos objets et équipements</p>
                    </div>
                </div>
                <div class="menu-card" id="card-shop">
                    <div class="menu-card-content">
                        <div class="menu-card-icon">🏪</div>
                        <h3>Boutique</h3>
                        <p>Achetez des gemmes et invoquez des héros</p>
                    </div>
                </div>
            </div>
        `;
        mainMenu.style.display = 'none';
        this.uiLayer.appendChild(mainMenu);

        // Create Equipment Screen - NOUVELLE VERSION AVEC ÉQUIPE HORIZONTALE
        const equipScreen = document.createElement('div');
        equipScreen.id = this.screens.EQUIPMENT;
        equipScreen.className = 'screen equipment-screen';
        equipScreen.innerHTML = `
            <div class="equipment-new-layout">
                <!-- Équipe de combat en ligne horizontale -->
                <div class="party-section">
                    <h3>⚔️ Équipe de Combat</h3>
                    <div id="party-units" class="party-horizontal"></div>
                </div>
                
                <!-- Équipements disponibles en grille -->
                <div class="equipment-section">
                    <h3>🎒 Tous les Équipements</h3>
                    <div id="equipment-grid" class="equipment-grid"></div>
                </div>
            </div>
            <button id="btn-back-equip" class="btn-back">← Retour</button>
        `;
        equipScreen.style.display = 'none';
        this.uiLayer.appendChild(equipScreen);

        // Create Battle HUD
        const battleHud = document.createElement('div');
        battleHud.id = this.screens.BATTLE_HUD;
        battleHud.className = 'screen';
        battleHud.innerHTML = `
            <div id="battle-info">Début du combat !</div>
            <button id="btn-flee">Fuir</button>
        `;
        battleHud.style.display = 'none';
        this.uiLayer.appendChild(battleHud);

        // Create Shop Screen
        const shopScreen = document.createElement('div');
        shopScreen.id = this.screens.SHOP;
        shopScreen.className = 'screen';
        shopScreen.innerHTML = `
            <h2 style="font-family: 'Poppins', sans-serif; font-size: 36px; margin-bottom: 30px;">🏪 Boutique</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; max-width: 1000px; width: 90%;">
                <div class="shop-section">
                    <h3 style="font-family: 'Poppins', sans-serif; color: var(--gold-color); margin-bottom: 20px;">💎 Gemmes Premium</h3>
                    <div style="display: flex; flex-direction: column; gap: 15px;">
                        <div class="shop-item">
                            <div class="shop-item-icon">💎</div>
                            <div class="shop-item-info">
                                <h4>Pack Starter</h4>
                                <p>1 Gemme</p>
                            </div>
                            <button id="btn-buy-gems-1" class="shop-buy-btn">0,99€</button>
                        </div>
                        <div class="shop-item featured">
                            <div class="best-value-badge">MEILLEURE OFFRE</div>
                            <div class="shop-item-icon">💎</div>
                            <div class="shop-item-info">
                                <h4>Pack Premium</h4>
                                <p>10 Gemmes</p>
                            </div>
                            <button id="btn-buy-gems-10" class="shop-buy-btn gold">8,99€</button>
                        </div>
                    </div>
                </div>
                <div class="shop-section">
                    <h3 style="font-family: 'Poppins', sans-serif; color: var(--gold-color); margin-bottom: 20px;">✨ Portail d'Invocation</h3>
                    <div class="summon-portal">
                        <div class="portal-glow"></div>
                        <div class="portal-content">
                            <div style="font-size: 64px; margin-bottom: 20px;">🌟</div>
                            <h4 style="font-family: 'Poppins', sans-serif; font-size: 20px; margin-bottom: 10px;">Invoquer un Héros</h4>
                            <p style="color: var(--text-secondary); margin-bottom: 20px;">Obtenez un nouveau personnage aléatoire !</p>
                            <button id="btn-summon" class="summon-btn">Invoquer (5 💎)</button>
                        </div>
                    </div>
                </div>
            </div>
            <button id="btn-back-shop" class="btn-back">← Retour</button>
        `;
        shopScreen.style.display = 'none';
        this.uiLayer.appendChild(shopScreen);

        // Create Inventory Screen
        const inventoryScreen = document.createElement('div');
        inventoryScreen.id = this.screens.INVENTORY;
        inventoryScreen.className = 'screen';
        inventoryScreen.innerHTML = `
            <div class="inventory-header">
                <h2>🎒 Inventaire</h2>
                <div class="gold-display">
                    <span class="resource-icon">🪙</span>
                    <span id="inventory-gold">0</span> Or
                </div>
            </div>
            <div class="inventory-rpg-container">
                <!-- COLONNE GAUCHE : Fiche Perso -->
                <div class="character-sheet-panel">
                    <!-- Sélecteur de Héros -->
                    <div class="hero-selector-container">
                        <div id="hero-selector-list" class="hero-list"></div>
                    </div>

                    <!-- Zone Principale Personnage -->
                    <div class="character-display-area">
                        <h3 id="rpg-hero-name" class="rpg-hero-name">Sélectionnez un héros</h3>
                        
                        <div class="character-visual-container">
                            <!-- Slots d'équipement autour -->
                            <div class="equipment-slot slot-left" data-slot="weapon" id="rpg-slot-weapon" title="Arme">
                                <div class="slot-icon">⚔️</div>
                                <div class="slot-item-img"></div>
                                <button class="btn-unequip-rpg" style="display: none;">✖</button>
                            </div>
                            
                            <div class="character-avatar-large" id="rpg-hero-avatar"></div>
                            
                            <div class="equipment-slot slot-right" data-slot="armor" id="rpg-slot-armor" title="Armure">
                                <div class="slot-icon">🛡️</div>
                                <div class="slot-item-img"></div>
                                <button class="btn-unequip-rpg" style="display: none;">✖</button>
                            </div>

                            <div class="equipment-slot slot-bottom" data-slot="accessory" id="rpg-slot-accessory" title="Accessoire">
                                <div class="slot-icon">💍</div>
                                <div class="slot-item-img"></div>
                                <button class="btn-unequip-rpg" style="display: none;">✖</button>
                            </div>
                        </div>

                        <!-- Stats -->
                        <div class="character-stats-rpg" id="rpg-hero-stats">
                            <!-- Rempli par JS -->
                        </div>
                    </div>
                </div>

                <!-- COLONNE DROITE : Inventaire -->
                <div class="inventory-grid-panel">
                    <div class="inventory-tabs">
                        <button class="tab-btn active" data-tab="all">Tout</button>
                        <button class="tab-btn" data-tab="weapon">Armes</button>
                        <button class="tab-btn" data-tab="armor">Armures</button>
                        <button class="tab-btn" data-tab="accessory">Accessoires</button>
                    </div>
                    <div id="rpg-inventory-grid" class="rpg-items-grid"></div>
                </div>
            </div>
            <button id="btn-back-inventory" class="btn-back">← Retour</button>
        `;
        inventoryScreen.style.display = 'none';
        this.uiLayer.appendChild(inventoryScreen);

        // Attach inventory event listeners immediately after creation
        const invBackBtn = inventoryScreen.querySelector('#btn-back-inventory');
        if (invBackBtn) {
            invBackBtn.addEventListener('click', () => {
                this.showScreen(this.screens.MAIN_MENU);
            });
        }

        inventoryScreen.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                inventoryScreen.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                const type = e.target.dataset.tab;
                this.updateInventoryGrid(type);
            });
        });

        // Create Quest Selection Screen
        const questScreen = document.createElement('div');
        questScreen.id = this.screens.QUEST_SELECT;
        questScreen.className = 'screen';
        questScreen.innerHTML = `
            <h2>Sélectionner une Quête</h2>
            <div id="quest-list" style="overflow-y: auto; max-height: 60%; width: 80%; background: rgba(255,255,255,0.1); padding: 10px;"></div>
            <button id="btn-back-quest">Retour</button>
        `;
        questScreen.style.display = 'none';
        this.uiLayer.appendChild(questScreen);

        // Create Evolution Screen
        const evolutionScreen = document.createElement('div');
        evolutionScreen.id = this.screens.EVOLUTION;
        evolutionScreen.className = 'screen';
        evolutionScreen.innerHTML = `
            <h2>🌟 Évolution</h2>
            <div class="evolution-container">
                <div class="evolution-source">
                    <h3>Avant</h3>
                    <div id="evo-before" class="evolution-preview">
                        <p>Sélectionnez une unité</p>
                    </div>
                </div>
                <div class="evolution-arrow">→</div>
                <div class="evolution-result">
                    <h3>Après</h3>
                    <div id="evo-after" class="evolution-preview">
                        <p>---</p>
                    </div>
                </div>
            </div>
            <div class="evolution-requirements">
                <h3>Matériaux Requis</h3>
                <div id="evo-materials"></div>
                <div id="evo-cost" class="cost-display"></div>
            </div>
            <div class="evolution-actions">
                <button id="btn-evolve" class="btn-evolve" disabled>Évoluer</button>
                <button id="btn-back-evolution" class="btn-back">← Retour</button>
            </div>
        `;
        evolutionScreen.style.display = 'none';
        this.uiLayer.appendChild(evolutionScreen);

        this.bindEvents();
    }

    updateEquipmentScreen() {
        this.renderPartyUnits();
        this.renderEquipmentGrid();
    }

    renderPartyUnits() {
        const partyContainer = document.getElementById('party-units');
        if (!partyContainer) return;

        partyContainer.innerHTML = '';
        const party = this.game.partyManager.getParty();

        if (party.length === 0) {
            partyContainer.innerHTML = '<div class="empty-party">Aucune unité dans l\'équipe</div>';
            return;
        }

        party.forEach(unit => {
            const unitCard = document.createElement('div');
            unitCard.className = 'party-unit-card';

            const colors = {
                'fire': '#e74c3c', 'water': '#3498db', 'earth': '#27ae60',
                'thunder': '#f39c12', 'light': '#ecf0f1', 'dark': '#34495e', 'none': '#95a5a6'
            };

            unitCard.innerHTML = `
                <div class="unit-sprite" style="background-color: ${colors[unit.element] || colors['none']}"></div>
                <div class="unit-name">${unit.name}</div>
                <div class="unit-rarity">${unit.getRarityStars()}</div>
                <div class="unit-level">Niv. ${unit.level}</div>
                <div class="unit-stats-mini">
                    <span>❤️ ${unit.hp}</span>
                    <span>⚔️ ${unit.atk}</span>
                    <span>🛡️ ${unit.def}</span>
                </div>
            `;

            partyContainer.appendChild(unitCard);
        });
    }

    renderEquipmentGrid() {
        const gridContainer = document.getElementById('equipment-grid');
        if (!gridContainer) return;

        gridContainer.innerHTML = '';
        const allUnits = this.game.partyManager.getAllUnits();

        if (allUnits.length === 0) {
            gridContainer.innerHTML = '<div class="empty-equipment">Aucun personnage disponible</div>';
            return;
        }

        allUnits.forEach(unit => {
            const unitCard = document.createElement('div');
            unitCard.className = 'equipment-item-card';

            const colors = {
                'fire': '#e74c3c', 'water': '#3498db', 'earth': '#27ae60',
                'thunder': '#f39c12', 'light': '#ecf0f1', 'dark': '#34495e', 'none': '#95a5a6'
            };

            const isInParty = this.game.partyManager.isInParty(unit);
            const partyBadge = isInParty ? '<div class="party-badge">⚔️ En équipe</div>' : '';

            unitCard.innerHTML = `
                <div class="unit-sprite-large" style="background-color: ${colors[unit.element] || colors['none']}"></div>
                ${partyBadge}
                <div class="unit-name">${unit.name}</div>
                <div class="unit-rarity">${unit.getRarityStars()}</div>
                <div class="unit-level">Niv. ${unit.level}</div>
                <div class="unit-stats">
                    <div>❤️ ${unit.hp}/${unit.getStat('maxHp')}</div>
                    <div>⚔️ ${unit.atk}</div>
                    <div>🛡️ ${unit.def}</div>
                </div>
                <button class="btn-toggle-party-inline">${isInParty ? 'Retirer' : 'Ajouter'}</button>
            `;

            const toggleBtn = unitCard.querySelector('.btn-toggle-party-inline');
            toggleBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (isInParty) {
                    this.game.partyManager.removeFromParty(unit);
                } else {
                    if (!this.game.partyManager.addToParty(unit)) {
                        alert('Équipe complète ! (Maximum 5 unités)');
                    }
                }
                this.updateEquipmentScreen();
            });

            gridContainer.appendChild(unitCard);
        });
    }

    updateCharacterList() {
        const partyList = document.getElementById('party-list');
        const ownedList = document.getElementById('owned-list');

        if (!partyList || !ownedList) return;

        partyList.innerHTML = '';
        ownedList.innerHTML = '';

        const party = this.game.partyManager.getParty();
        const notInParty = this.game.partyManager.getUnitsNotInParty();
        const selected = this.game.partyManager.getSelectedUnit();

        party.forEach(unit => {
            const card = this.createCharacterCard(unit, true, selected === unit);
            partyList.appendChild(card);
        });

        notInParty.forEach(unit => {
            const card = this.createCharacterCard(unit, false, selected === unit);
            ownedList.appendChild(card);
        });
    }

    createCharacterCard(unit, inParty, isSelected) {
        const card = document.createElement('div');
        card.className = 'character-card';
        if (inParty) card.classList.add('in-party');
        if (isSelected) card.classList.add('selected');

        // Check if evolution is possible
        const canEvolve = unit.canEvolve();
        const duplicates = this.game.evolutionSystem.findDuplicates(unit);
        const hasEnoughDuplicates = duplicates.length >= 2;
        const evolutionPossible = canEvolve && hasEnoughDuplicates;

        const evolutionBadge = evolutionPossible
            ? '<span class="evolution-badge">🌟 Évolution!</span>'
            : '';

        card.innerHTML = `
            <div class="char-name">${unit.name}</div>
            <div class="char-element">${unit.element} ${unit.getRarityStars()}</div>
            ${evolutionBadge}
        `;

        card.addEventListener('click', () => this.selectCharacter(unit));
        return card;
    }

    selectCharacter(unit) {
        this.game.partyManager.selectUnit(unit);

        document.getElementById('no-selection').style.display = 'none';
        document.getElementById('character-info').style.display = 'block';

        this.updateCharacterDetail(unit);
        this.updateCharacterList();
    }

    updateCharacterDetail(unit) {
        document.getElementById('char-name').textContent = unit.name;
        document.getElementById('char-element').textContent = unit.element.toUpperCase();
        document.getElementById('char-rarity').textContent = '⭐'.repeat(unit.rarity);
        document.getElementById('char-description').textContent = unit.description || 'Aucune description';

        const sprite = document.getElementById('char-sprite');
        const colors = {
            'fire': '#e74c3c', 'water': '#3498db', 'earth': '#27ae60',
            'thunder': '#f39c12', 'light': '#ecf0f1', 'dark': '#34495e', 'none': '#95a5a6'
        };
        sprite.style.backgroundColor = colors[unit.element] || colors['none'];

        this.updateStatsDisplay(unit);
        this.updateEquipmentSlots(unit);
        this.updateInventoryForEquip(unit);

        const btn = document.getElementById('btn-toggle-party');
        if (this.game.partyManager.isInParty(unit)) {
            btn.textContent = "Retirer de l'équipe";
            btn.onclick = () => {
                this.game.partyManager.removeFromParty(unit);
                this.updateCharacterList();
                this.updateCharacterDetail(unit);
            };
        } else {
            btn.textContent = "Ajouter à l'équipe";
            btn.onclick = () => {
                if (this.game.partyManager.addToParty(unit)) {
                    this.updateCharacterList();
                    this.updateCharacterDetail(unit);
                } else {
                    alert('Équipe complète ! (Maximum 5 unités)');
                }
            };
        }
    }

    updateStatsDisplay(unit) {
        const statsDisplay = document.getElementById('stats-display');
        const atkBonus = unit.getStat('atk') - unit.atk;
        const defBonus = unit.getStat('def') - unit.def;
        const maxHp = unit.getStat('maxHp');

        const evolutionButton = unit.canEvolve()
            ? `<button id="btn-evolve-unit" class="btn-evolve" style="margin-top: 16px; width: 100%;">🌟 Évoluer (${unit.getRarityStars()} → ${'★'.repeat(unit.currentRarity + 1)})</button>`
            : '';

        statsDisplay.innerHTML = `
            <div class="stat-row level-row">
                <span class="stat-label">⭐ Niveau :</span>
                <span class="stat-value">${unit.level}</span>
            </div>
            <div class="stat-row xp-row">
                <span class="stat-label">📊 XP :</span>
                <span class="stat-value">${unit.xp} / ${unit.xpToNextLevel}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">🌟 Rang :</span>
                <span class="stat-value">${unit.getRarityStars()} / ${unit.getMaxRarityStars()}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">❤️ HP :</span>
                <span class="stat-value">${unit.hp} / ${maxHp}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">⚔️ ATK :</span>
                <span class="stat-value">${unit.atk}${atkBonus > 0 ? ' (+' + atkBonus + ')' : ''}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">🛡️ DEF :</span>
                <span class="stat-value">${unit.def}${defBonus > 0 ? ' (+' + defBonus + ')' : ''}</span>
            </div>
            <div class="stat-row">
                <span class="stat-label">💫 BB :</span>
                <span class="stat-value">${unit.bbGauge} / ${unit.maxBbGauge}</span>
            </div>
            ${evolutionButton}
        `;

        // Add event listener for evolution button if it exists
        if (unit.canEvolve()) {
            setTimeout(() => {
                const btn = document.getElementById('btn-evolve-unit');
                if (btn) {
                    btn.onclick = () => this.openEvolutionScreen(unit);
                }
            }, 0);
        }
    }

    updateEquipmentSlots(unit) {
        const equipment = unit.getEquipment();

        ['weapon', 'armor', 'accessory'].forEach(slot => {
            const slotEl = document.getElementById(`slot-${slot}`);
            const unequipBtn = document.querySelector(`.btn-unequip[data-slot="${slot}"]`);

            if (equipment[slot]) {
                const statsStr = this.getItemStatsString(equipment[slot]);
                slotEl.innerHTML = `
                    <div class="equipped-name">${equipment[slot].name}</div>
                    <div class="equipped-desc">${statsStr}</div>
                `;
                slotEl.classList.add('equipped');
                unequipBtn.style.display = 'inline-block';
                unequipBtn.onclick = () => {
                    const item = unit.unequipItem(slot);
                    if (item) {
                        this.game.economySystem.addItem(item);
                    }
                    this.updateCharacterDetail(unit);
                };
                unequipBtn.style.display = 'none';
            }
        });
    }

    updateInventoryForEquip(unit) {
        const inventoryGrid = document.getElementById('inventory-items');
        if (!inventoryGrid) return;
        inventoryGrid.innerHTML = '';

        const inventory = this.game.economySystem.inventory;

        if (inventory.length === 0) {
            inventoryGrid.innerHTML = "<p class='empty-message'>Aucun objet dans l'inventaire</p>";
            return;
        }

        inventory.forEach(item => {
            const itemCard = document.createElement('div');
            itemCard.className = 'inventory-item';
            const statsStr = this.getItemStatsString(item);
            itemCard.innerHTML = `
                <div class="item-name">${item.name}</div>
                <div class="item-desc">${statsStr}</div>
                <div class="item-type">${item.type}</div>
            `;

            itemCard.addEventListener('click', () => {
                if (unit.equip(item)) {
                    this.game.economySystem.removeItem(item);
                    this.updateCharacterDetail(unit);
                }
            });

            inventoryGrid.appendChild(itemCard);
        });
    }

    getItemStatsString(item) {
        if (!item || !item.stats) return '';
        const stats = [];
        if (item.stats.atk) stats.push(`ATK +${item.stats.atk}`);
        if (item.stats.def) stats.push(`DEF +${item.stats.def}`);
        if (item.stats.maxHp) stats.push(`HP +${item.stats.maxHp}`);
        return stats.join(', ');
    }

    updateQuestList() {
        const list = document.getElementById('quest-list');
        list.innerHTML = '';

        this.game.questSystem.quests.forEach(quest => {
            const el = document.createElement('div');
            el.style.padding = '15px';
            el.style.borderBottom = '1px solid #eee';
            el.style.display = 'flex';
            el.style.justifyContent = 'space-between';
            el.style.alignItems = 'center';

            el.innerHTML = `
                <div>
                    <h3>${quest.name}</h3>
                    <p>${quest.description}</p>
                </div>
                <button>Commencer (${quest.energyCost} Énergie)</button>
            `;

            el.querySelector('button').addEventListener('click', () => {
                console.log(`Clic sur commencer la quête : ${quest.name}`);
                this.game.startBattle();
                this.game.questSystem.startQuest(quest.id);
            });

            list.appendChild(el);
        });
    }

    bindEvents() {
        // Main Menu Card Navigation
        document.getElementById('card-battle').addEventListener('click', () => {
            this.showScreen(this.screens.QUEST_SELECT);
        });

        document.getElementById('card-equip').addEventListener('click', () => {
            this.showScreen(this.screens.EQUIPMENT);
        });

        document.getElementById('card-shop').addEventListener('click', () => {
            this.showScreen(this.screens.SHOP);
        });

        document.getElementById('btn-back-equip').addEventListener('click', () => {
            this.showScreen(this.screens.MAIN_MENU);
        });

        document.getElementById('btn-flee').addEventListener('click', () => {
            this.game.endBattle();
        });

        // Shop Events
        document.getElementById('btn-back-shop').addEventListener('click', () => {
            this.showScreen(this.screens.MAIN_MENU);
        });

        document.getElementById('btn-buy-gems-1').addEventListener('click', () => {
            this.game.economySystem.buyGems(1);
            this.updateResourceDisplay();
            console.log('Purchased 1 Gem!');
        });

        document.getElementById('btn-buy-gems-10').addEventListener('click', () => {
            this.game.economySystem.buyGems(10);
            this.updateResourceDisplay();
            console.log('Purchased 10 Gems!');
        });

        document.getElementById('btn-summon').addEventListener('click', () => {
            if (this.game.economySystem.spendResource('gems', 5)) {
                this.updateResourceDisplay();
                console.log('Summoned a new Unit! (Placeholder)');
            } else {
                console.log('Not enough Gems!');
            }
        });


        // Inventory Events
        const backBtn = document.getElementById('btn-back-inventory');
        console.log('btn-back-inventory element:', backBtn);

        document.getElementById('card-inventory').addEventListener('click', () => {
            this.openInventoryScreen();
        });

        if (backBtn) {
            backBtn.addEventListener('click', () => {
                console.log('Back button clicked - returning to main menu');
                this.showScreen(this.screens.MAIN_MENU);
            });
        } else {
            console.error('btn-back-inventory not found!');
        }

        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                const type = e.target.dataset.tab;
                this.updateInventoryGrid(type);
            });
        });

        // Quest Events
        document.getElementById('btn-back-quest').addEventListener('click', () => {
            this.showScreen(this.screens.MAIN_MENU);
        });

        // Evolution Events
        document.getElementById('btn-back-evolution').addEventListener('click', () => {
            this.showScreen(this.screens.EQUIPMENT);
        });

        document.getElementById('btn-evolve').addEventListener('click', () => {
            this.performEvolution();
        });
    }

    showScreen(screenId) {
        // Hide all screens
        Object.values(this.screens).forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = 'none';
        });

        // Show requested screen
        const target = document.getElementById(screenId);
        if (target) target.style.display = 'flex';
        this.currentScreen = screenId;

        if (screenId === this.screens.EQUIPMENT) {
            this.updateEquipmentScreen();
        } else if (screenId === this.screens.QUEST_SELECT) {
            this.updateQuestList();
        } else if (screenId === this.screens.MAIN_MENU) {
            this.updateResourceDisplay();
        }
    }

    updateResourceDisplay() {
        const gemsEl = document.getElementById('gems-count');
        const goldEl = document.getElementById('gold-count');
        const energyEl = document.getElementById('energy-count');

        if (gemsEl) gemsEl.textContent = this.game.economySystem.resources.gems || 0;
        if (goldEl) goldEl.textContent = this.game.economySystem.resources.gold || 0;
        if (energyEl) energyEl.textContent = this.game.economySystem.resources.energy || 100;
    }

    updateBattleInfo(text) {
        const info = document.getElementById('battle-info');
        if (info) info.textContent = text;
    }

    showDamageNumber(x, y, amount, color = 'white') {
        const el = document.createElement('div');
        el.textContent = amount;
        el.style.position = 'absolute';
        el.style.left = `${x + 20}px`;
        el.style.top = `${y}px`;
        el.style.color = color;
        el.style.fontSize = '24px';
        el.style.fontWeight = 'bold';
        el.style.textShadow = '2px 2px 0 #000';
        el.style.pointerEvents = 'none';
        el.style.animation = 'floatUp 1s ease-out forwards';

        // Add keyframes if not exists
        if (!document.getElementById('anim-style')) {
            const style = document.createElement('style');
            style.id = 'anim-style';
            style.textContent = `
                @keyframes floatUp {
                    0% { transform: translateY(0); opacity: 1; }
                    100% { transform: translateY(-50px); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
        }

        this.uiLayer.appendChild(el);
        setTimeout(() => el.remove(), 1000);
    }

    showBattleMessage(text) {
        const el = document.createElement('div');
        el.textContent = text;
        el.style.position = 'absolute';
        el.style.top = '20%';
        el.style.width = '100%';
        el.style.textAlign = 'center';
        el.style.color = 'gold';
        el.style.fontSize = '30px';
        el.style.fontWeight = 'bold';
        el.style.textShadow = '0 0 10px black';
        el.style.pointerEvents = 'none';
        el.style.animation = 'fadeOut 2s forwards';

        // Add keyframes if not exists
        if (!document.getElementById('msg-anim-style')) {
            const style = document.createElement('style');
            style.id = 'msg-anim-style';
            style.textContent = `
                @keyframes fadeOut {
                    0% { opacity: 1; transform: scale(1); }
                    80% { opacity: 1; transform: scale(1.1); }
                    100% { opacity: 0; transform: scale(1.2); }
                }
            `;
            document.head.appendChild(style);
        }

        this.uiLayer.appendChild(el);
        setTimeout(() => el.remove(), 2000);
    }

    // Evolution Methods
    openEvolutionScreen(unit) {
        this.selectedEvolutionUnit = unit;
        this.showScreen(this.screens.EVOLUTION);
        this.updateEvolutionScreen();
    }

    updateEvolutionScreen() {
        const unit = this.selectedEvolutionUnit;
        if (!unit) return;

        const beforeDiv = document.getElementById('evo-before');
        const afterDiv = document.getElementById('evo-after');
        const materialsDiv = document.getElementById('evo-materials');
        const costDiv = document.getElementById('evo-cost');
        const evolveBtn = document.getElementById('btn-evolve');

        // Display current unit stats
        beforeDiv.innerHTML = `
            <div class="unit-preview">
                <h4>${unit.name}</h4>
                <p class="rarity-stars">${unit.getRarityStars()}</p>
                <p>Niveau ${unit.level}</p>
                <div class="stats-preview">
                    <p>HP: ${unit.hp}</p>
                    <p>ATK: ${unit.atk}</p>
                    <p>DEF: ${unit.def}</p>
                </div>
            </div>
        `;

        // Check if evolution is possible
        const check = this.game.evolutionSystem.canPerformEvolution(unit);

        if (check.possible) {
            // Show preview of evolved stats
            const preview = this.game.evolutionSystem.getEvolutionPreview(unit);
            afterDiv.innerHTML = `
                <div class="unit-preview">
                    <h4>${unit.name}</h4>
                    <p class="rarity-stars">${'★'.repeat(preview.nextRarity)}</p>
                    <p>Niveau 1</p>
                    <div class="stats-preview">
                        <p>HP: ${preview.nextStats.hp} <span class="stat-increase">+${preview.nextStats.hp - preview.currentStats.hp}</span></p>
                        <p>ATK: ${preview.nextStats.atk} <span class="stat-increase">+${preview.nextStats.atk - preview.currentStats.atk}</span></p>
                        <p>DEF: ${preview.nextStats.def} <span class="stat-increase">+${preview.nextStats.def - preview.currentStats.def}</span></p>
                    </div>
                </div>
            `;

            // Show materials
            materialsDiv.innerHTML = `
                <p>✓ 2 Duplicatas disponibles</p>
            `;

            // Show cost
            costDiv.innerHTML = `
                <p>💰 Coût: ${check.cost.toLocaleString()} Or</p>
            `;

            // Enable button
            evolveBtn.disabled = false;
        } else {
            // Show why evolution is not possible
            afterDiv.innerHTML = `
                <div class="unit-preview">
                    <p>Évolution impossible</p>
                </div>
            `;

            materialsDiv.innerHTML = `
                <p class="error">✗ ${check.reason}</p>
            `;

            costDiv.innerHTML = '';
            evolveBtn.disabled = true;
        }
    }

    performEvolution() {
        const unit = this.selectedEvolutionUnit;
        if (!unit) return;

        const check = this.game.evolutionSystem.canPerformEvolution(unit);
        if (!check.possible) {
            alert(check.reason);
            return;
        }

        // Perform evolution
        const success = this.game.evolutionSystem.evolveUnit(unit, check.duplicates);

        if (success) {
            alert(`✨ ${unit.name} a évolué vers ${unit.getRarityStars()} !`);
            this.updateResourceDisplay();
            this.showScreen(this.screens.EQUIPMENT);
            this.updateEquipmentScreen();
            // Force refresh of the unit display to show new stats and rank
            this.updateCharacterDetail(unit);
        } else {
            alert('Échec de l\'évolution');
        }
    }

    openInventoryScreen() {
        this.showScreen(this.screens.INVENTORY);
        this.updateInventoryScreen();
    }

    updateInventoryScreen() {
        const gold = this.game.economySystem.resources.gold || 0;
        const goldDisplay = document.getElementById('inventory-gold');
        if (goldDisplay) {
            goldDisplay.textContent = gold.toLocaleString();
        }

        // Render party units at the top
        this.renderInventoryPartyUnits();

        // Render items grid
        this.updateInventoryGrid('all');
    }

    renderInventoryPartyUnits() {
        const selectorList = document.getElementById('hero-selector-list');
        if (!selectorList) return;

        selectorList.innerHTML = '';
        const party = this.game.partyManager.getParty();

        if (party.length === 0) {
            selectorList.innerHTML = '<div class="empty-party">Vide</div>';
            return;
        }

        party.forEach(unit => {
            const avatar = document.createElement('div');
            avatar.className = 'hero-avatar-small';

            const colors = {
                'fire': '#e74c3c', 'water': '#3498db', 'earth': '#27ae60',
                'thunder': '#f39c12', 'light': '#ecf0f1', 'dark': '#34495e', 'none': '#95a5a6'
            };
            avatar.style.backgroundColor = colors[unit.element] || colors['none'];
            avatar.title = unit.name;

            if (this.selectedHeroForEquipment === unit) {
                avatar.classList.add('selected');
            }

            avatar.addEventListener('click', () => {
                this.selectHeroForEquipment(unit);
            });

            selectorList.appendChild(avatar);
        });

        // Select first hero by default if none selected
        if (!this.selectedHeroForEquipment && party.length > 0) {
            this.selectHeroForEquipment(party[0]);
        }
    }

    selectHeroForEquipment(unit) {
        this.selectedHeroForEquipment = unit;

        // Update visual selection in list
        document.querySelectorAll('.hero-avatar-small').forEach(av => {
            av.classList.remove('selected');
            if (av.title === unit.name) av.classList.add('selected'); // Simple check by name
        });

        // Update main display
        this.updateHeroEquipmentDisplay(unit);
        console.log(`Héros sélectionné: ${unit.name}`);
    }

    updateHeroEquipmentDisplay(unit) {
        // Update Name
        const nameEl = document.getElementById('rpg-hero-name');
        if (nameEl) nameEl.textContent = unit.name;

        // Update Large Avatar
        const avatarEl = document.getElementById('rpg-hero-avatar');
        if (avatarEl) {
            const colors = {
                'fire': '#e74c3c', 'water': '#3498db', 'earth': '#27ae60',
                'thunder': '#f39c12', 'light': '#ecf0f1', 'dark': '#34495e', 'none': '#95a5a6'
            };
            avatarEl.style.backgroundColor = colors[unit.element] || colors['none'];
        }

        // Update Slots
        const slots = ['weapon', 'armor', 'accessory'];
        slots.forEach(slot => {
            const slotEl = document.getElementById(`rpg-slot-${slot}`);
            if (!slotEl) return;

            const itemImg = slotEl.querySelector('.slot-item-img');
            const unequipBtn = slotEl.querySelector('.btn-unequip-rpg');
            const iconEl = slotEl.querySelector('.slot-icon');

            if (unit.equipment && unit.equipment[slot]) {
                const item = unit.equipment[slot];
                // Show item
                let icon = '❓';
                if (item.type === 'weapon') icon = '⚔️';
                if (item.type === 'armor') icon = '🛡️';
                if (item.type === 'accessory') icon = '💍';

                if (itemImg) {
                    itemImg.textContent = icon;
                    itemImg.style.display = 'flex';
                }
                if (iconEl) iconEl.style.opacity = '0'; // Hide default icon
                if (unequipBtn) {
                    unequipBtn.style.display = 'none'; // Hidden by default, shown on hover via CSS
                    unequipBtn.onclick = (e) => {
                        e.stopPropagation();
                        this.unequipItemFromHero(unit, slot);
                    };
                }
                slotEl.title = `${item.name} (Niv. ${item.level || 1})`;
                slotEl.classList.add('equipped');
            } else {
                // Empty slot
                if (itemImg) {
                    itemImg.textContent = '';
                    itemImg.style.display = 'none';
                }
                if (iconEl) iconEl.style.opacity = '0.3'; // Show default icon
                if (unequipBtn) unequipBtn.style.display = 'none';
                slotEl.title = slot.charAt(0).toUpperCase() + slot.slice(1);
                slotEl.classList.remove('equipped');
            }
        });

        // Update Stats
        const statsEl = document.getElementById('rpg-hero-stats');
        if (statsEl) {
            const baseAtk = unit.atk;
            const baseDef = unit.def;
            const baseHp = unit.getStat('maxHp');

            const totalAtk = unit.getStat('atk');
            const totalDef = unit.getStat('def');
            const totalHp = unit.getStat('maxHp');

            const atkBonus = totalAtk - baseAtk;
            const defBonus = totalDef - baseDef;
            const hpBonus = totalHp - baseHp;

            statsEl.innerHTML = `
                <div class="rpg-stat-row">
                    <span class="rpg-stat-label">HP</span>
                    <span class="rpg-stat-value">${totalHp} ${hpBonus > 0 ? `<span class="rpg-stat-bonus">(+${hpBonus})</span>` : ''}</span>
                </div>
                <div class="rpg-stat-row">
                    <span class="rpg-stat-label">ATK</span>
                    <span class="rpg-stat-value">${totalAtk} ${atkBonus > 0 ? `<span class="rpg-stat-bonus">(+${atkBonus})</span>` : ''}</span>
                </div>
                <div class="rpg-stat-row">
                    <span class="rpg-stat-label">DEF</span>
                    <span class="rpg-stat-value">${totalDef} ${defBonus > 0 ? `<span class="rpg-stat-bonus">(+${defBonus})</span>` : ''}</span>
                </div>
            `;
        }
    }

    unequipItemFromHero(unit, slot) {
        if (!unit.equipment || !unit.equipment[slot]) return;

        const item = unit.equipment[slot];

        // Remove from unit
        unit.unequip(slot);

        // Add back to inventory
        this.game.economySystem.inventory.push(item);

        // Refresh displays
        this.updateHeroEquipmentDisplay(unit);

        // Get current filter tab
        const activeTab = document.querySelector('.tab-btn.active');
        const filterType = activeTab ? activeTab.dataset.tab : 'all';
        this.updateInventoryGrid(filterType);

        this.renderInventoryPartyUnits();
    }

    equipItemOnSelectedHero(item) {
        const unit = this.selectedHeroForEquipment;
        if (!unit) return;

        // Determine slot based on item type
        let slot = item.type;

        // Check if slot is already occupied
        if (unit.equipment && unit.equipment[slot]) {
            const oldItem = unit.equipment[slot];
            this.game.economySystem.inventory.push(oldItem);
        }

        // Equip the item
        unit.equip(item);

        // Remove from inventory
        const index = this.game.economySystem.inventory.indexOf(item);
        if (index > -1) {
            this.game.economySystem.inventory.splice(index, 1);
        }

        // Refresh displays
        this.updateHeroEquipmentDisplay(unit);

        // Get current filter tab
        const activeTab = document.querySelector('.tab-btn.active');
        const filterType = activeTab ? activeTab.dataset.tab : 'all';
        this.updateInventoryGrid(filterType);
        this.renderInventoryPartyUnits();
    }

    updateInventoryGrid(filterType) {
        const grid = document.getElementById('rpg-inventory-grid');
        if (!grid) return;

        grid.innerHTML = '';
        const inventory = this.game.economySystem.inventory;

        let filteredItems = inventory;
        if (filterType !== 'all') {
            filteredItems = inventory.filter(item => item.type === filterType);
        }

        if (filteredItems.length === 0) {
            grid.innerHTML = '<div class="empty-inventory">Aucun objet trouvé</div>';
            return;
        }

        filteredItems.forEach(item => {
            const itemCard = document.createElement('div');
            itemCard.className = 'rpg-item-card';

            let icon = '❓';
            if (item.type === 'weapon') icon = '⚔️';
            if (item.type === 'armor') icon = '🛡️';
            if (item.type === 'accessory') icon = '💍';

            itemCard.innerHTML = `
                <div class="rpg-item-icon">${icon}</div>
                <div class="rpg-item-level">Niv.${item.level || 1}</div>
            `;

            // Add tooltip
            itemCard.title = `${item.name}\n${item.type.toUpperCase()}\n${this.getItemStatsString(item)}\n${item.description || ''}`;

            // Add click event to equip on selected hero
            itemCard.addEventListener('click', () => {
                if (this.selectedHeroForEquipment) {
                    this.equipItemOnSelectedHero(item);
                } else {
                    alert('Sélectionnez d\'abord un héros !');
                }
            });

            grid.appendChild(itemCard);
        });
    }
}
